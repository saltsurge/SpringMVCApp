*********************************************************
***********     Just Spring Core Examples  **************
*********************************************************
This project has samples associated with the Just Spring book. I have tried to keep the code as clean as possible.

- The convention I followed is to provide individual package for a chapter and one or two resource files 

Please get in touch with me if you wish to raise any error or throw me some suggestions.

I hope you will enjoy the Just Spring Core book and examples.

Contact me:

Twitter: @mkonda007
home: www.madhusudhan.com
