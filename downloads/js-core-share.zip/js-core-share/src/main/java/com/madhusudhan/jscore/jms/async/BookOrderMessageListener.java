/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.madhusudhan.jscore.jms.async;

import javax.jms.Message;
import javax.jms.MessageListener;

/**
 *
 * @author mkonda
 */
public class BookOrderMessageListener implements MessageListener {

    @Override
    public void onMessage(Message msg) {
        System.out.println("Book order received:" + msg.toString());
    }
}
