/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.madhusudhan.jscore.containers.factory;

import com.madhusudhan.jscore.containers.Employee;

/**
 *
 * @author mkonda
 */
public class EmployeeCreator {

    public Employee createEmployee() {
        return new Employee();
    }

    public Employee createExecutive() {
        Employee emp = new Employee();
        emp.setTitle("EXEC");
        emp.setGrade("GRADE-A");
        return emp;
    }
}
