/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.madhusudhan.jscore.containers.event.publish;

import org.springframework.context.ApplicationEvent;

/**
 *
 * @author mkonda
 */
public class HugeFileEvent extends ApplicationEvent {

    private String fileName = null;
    public HugeFileEvent(Object source, String fileName) {
        super(source);
        this.fileName = fileName;
    }
}
