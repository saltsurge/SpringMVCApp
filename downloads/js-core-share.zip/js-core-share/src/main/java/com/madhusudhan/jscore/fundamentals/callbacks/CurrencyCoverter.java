/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.madhusudhan.jscore.fundamentals.callbacks;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author mkonda
 */
public class CurrencyCoverter {
    private String toCurrency = null;
    private String fromCurrency = null;
    private List<String> currencies = null;
    public CurrencyCoverter() {
        //impl goes here..
    }
    
    public void init(){
        currencies = new ArrayList<String>();
        
        currencies.add("GBP");
        currencies.add("USD");
        currencies.add("JPY");
        currencies.add("EUR");
        currencies.add("INR");
    }
   

}
