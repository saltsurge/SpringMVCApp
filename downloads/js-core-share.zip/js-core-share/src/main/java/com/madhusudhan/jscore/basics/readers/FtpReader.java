package com.madhusudhan.jscore.basics.readers;


public class FtpReader implements IReader {
  private String ftpHost = null;
  private int ftpPort = 0;
  
  @Override
  public String read() {
    return null;
  }

  public void setFtpHost(String ftpHost) {
    this.ftpHost = ftpHost;
  }

  public String getFtpHost() {
    return ftpHost;
  }

  public void setFtpPort(int ftpPort) {
    this.ftpPort = ftpPort;
  }

  public int getFtpPort() {
    return ftpPort;
  }

}
