/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.madhusudhan.jscore.fundamentals;

/**
 *
 * @author mkonda
 */
public class TrainMan {

    private String trainCompany = null;

    public TrainMan(int trainNumber) {
    }

    public TrainMan(int trainNumber, String trainName, boolean nightOnly, double maxFare) {
    }

    public String getTrainCompany() {
        return trainCompany;
    }

    public void setTrainCompany(String trainCompany) {
        this.trainCompany = trainCompany;
    }
}
