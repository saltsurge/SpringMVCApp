/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.madhusudhan.jscore.data.hib.nativ;

/**
 *
 * @author mkonda
 */
public class Trade {
    
}
