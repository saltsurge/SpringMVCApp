/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.madhusudhan.jscore.containers.postprocessor;

/**
 *
 * @author mkonda
 */
public class PostProcessComponent {
    private String componentName = null;

    public String getComponentName() {
        return componentName;
    }

    public void setComponentName(String componentName) {
        this.componentName = componentName;
    }

    @Override
    public String toString() {
        return "PostProcessComponent{" + "componentName=" + componentName + '}';
    }

   
}
