/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.madhusudhan.jscore.fundamentals.propertyeditor;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

/**
 *
 * @author mkonda
 */
public class CapitalCitiesManager {

    private List<String> countriesList = null;
    private Set<String> countriesSet = null;
    private Properties countryProperties = null;
    private Map<String,String> countriesCapitalsMap = null;
    private Map<String,Object> countriesCapitalsRefMap = null;

    public Map<String, Object> getCountriesCapitalsRefMap() {
        return countriesCapitalsRefMap;
    }

    public void setCountriesCapitalsRefMap(Map<String, Object> countriesCapitalsRefMap) {
        this.countriesCapitalsRefMap = countriesCapitalsRefMap;
    }

    public Map<String, String> getCountriesCapitalsMap() {
        return countriesCapitalsMap;
    }

    public void setCountriesCapitalsMap(Map<String, String> countriesCapitalsMap) {
        this.countriesCapitalsMap = countriesCapitalsMap;
    }

    public Properties getCountryProperties() {
        return countryProperties;
    }

    public void setCountryProperties(Properties countryProperties) {
        this.countryProperties = countryProperties;
    }

    public List<String> getCountriesList() {
        return countriesList;
    }

    public void setCountriesList(List<String> countriesList) {
        this.countriesList = countriesList;
    }

    public Set<String> getCountriesSet() {
        return countriesSet;
    }

    public void setCountriesSet(Set<String> countriesSet) {
        this.countriesSet = countriesSet;
    }
}
