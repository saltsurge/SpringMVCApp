/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.madhusudhan.jscore.fundamentals.injection;

/**
 *
 * @author mkonda
 */
public class FileReader {

    private String componentName = null;

    public FileReader(String fileName) {
        //impl goes here..
    }

    public String getComponentName() {
        return componentName;
    }

    public void setComponentName(String componentName) {
        this.componentName = componentName;
    }
}
