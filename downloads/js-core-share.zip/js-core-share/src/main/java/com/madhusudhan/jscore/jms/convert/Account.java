/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.madhusudhan.jscore.jms.convert;

import java.io.Serializable;

/**
 *
 * @author mkonda
 */
class Account implements Serializable{
    
}
