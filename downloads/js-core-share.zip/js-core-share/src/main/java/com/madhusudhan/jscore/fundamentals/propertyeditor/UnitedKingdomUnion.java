/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.madhusudhan.jscore.fundamentals.propertyeditor;

/**
 *
 * @author mkonda
 */
public class UnitedKingdomUnion {
 
    private String ENGLAND = "ENGLAND";

    
    private String SCOTLAND = "SCOTLAND";
    private String WALES = "WALES";
    private String N_IRELAND = "NORTHERN IRELAND";
    
    @Override
    public String toString() {
        return "UnitedKingdomUnion{" + "ENGLAND=" + ENGLAND + ", SCOTLAND=" + SCOTLAND + ", WALES=" + WALES + ", N_IRELAND=" + N_IRELAND + '}';
    }
}
